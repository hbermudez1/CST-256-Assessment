<?php
namespace App\Models;

class FormModel
{
    private $UserInputOne;
    private $UserInputTwo;
    private $UserInputThree;
    private $UserInputFour;
    
    
    //Class Constructor
    public function _construct($UserInputOne, $UserInputTwo, $UserInputThree, $UserInputFour)
    {
        $this->UserInputOne = $UserInputOne;
        $this->UserInputTwo = $UserInputTwo;
        $this->UserInputThree = $UserInputThree;
        $this->UserInputFour = $UserInputFour;
        
    }
    
    /*
     * Getter Method -> username
     * @return string
     * */
    public function getUserInputOne()
    {
        return $this->UserInputOne;
    }
    /*
     * Getter Method -> username
     * @return string
     * */
    public function getUserInputTwo()
    {
        return $this->UserInputTwo;
    }
    /*
     * Getter Method -> username
     * @return string
     * */
    public function getUserInputThree()
    {
        return $this->UserInputThree;
    }
    /*
     * Getter Method -> username
     * @return string
     * */
    public function getUserInputFour()
    {
        return $this->UserInputFour;
    }
    /*
     * Getter Method -> password
     * @return string
     * */
   
}