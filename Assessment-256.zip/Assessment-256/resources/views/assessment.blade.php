<html>
<head>

<title>Assessment</title>

</head>
<body>
	<div>

		<form action="addCustomer" method="POST">
			{{ csrf_field() }}
			
			<!-- Table Div -->
			<div class="demo-table">
			
				<div class="form-column">
				
				<!-- Begin Username -->
					<div>
						<label for="firstName">User Input One</label><span id="firstname_info"
							class="error-info"></span>
							


					</div>
					<div>
						<input name="firstName" id="firstName" type="text"
							class="demo-input-box">
					</div>

				</div>
				<!-- Begin Password -->
				<div class="form-column">
					<div>
						<label for="lastName">User Input Two</label><span id="lastname"
							class="error-info"></span>
							

					</div>
					<div>
						<input name="lastName" id="lastName" type="text"
							class="demo-input-box">
					</div>

				</div>
				<div class="form-column">
					<div>
						<label for="lastName">User Input Three</label><span id="lastname"
							class="error-info"></span>
							

					</div>
					<div>
						<input name="lastName" id="lastName" type="text"
							class="demo-input-box">
					</div>

				</div>
				<div class="form-column">
					<div>
						<label for="lastName">User Input Four</label><span id="lastname"
							class="error-info"></span>
							

					</div>
					<div>
						<input name="lastName" id="lastName" type="text"
							class="demo-input-box">
					</div>

				</div>
				<div>
					<input type="submit" class="btnLogin">
				</div>

			</div>



		</form>

	</div>

</body>


</html>